<?php

$dbServername = "localhost3306";
$dbUsername = "bbush1";
$dbPassword = "wtook88w";
$dbName = "users";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);